# hczc

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Run your tests
```
npm run test
```

### Lints and fixes files
```
npm run lint
```

### Run your unit tests
```
npm run test:unit
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

###这是一个基于element和vue实现的sku表格 用于电商展示等等 这只是一个大致的样子,

![](https://img-blog.csdnimg.cn/20190510105928622.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzQyMTI5NDIy,size_16,color_FFFFFF,t_70)

![](https://img-blog.csdnimg.cn/20190510110034501.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzQyMTI5NDIy,size_16,color_FFFFFF,t_70)
